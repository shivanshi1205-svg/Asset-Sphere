import React, { createContext, useContext, useState, useEffect } from 'react';
import apiClient from '../services/apiClient';

const AuthContext = createContext(null);

// Helper to update the CSRF meta tag in the DOM
const updateCsrfMeta = (token) => {
  if (!token) return;
  let meta = document.querySelector('meta[name="csrf-token"]');
  if (!meta) {
    meta = document.createElement('meta');
    meta.name = 'csrf-token';
    document.head.appendChild(meta);
  }
  meta.setAttribute('content', token);
  // Also configure axios default headers just in case
  apiClient.defaults.headers.common['X-CSRF-TOKEN'] = token;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Initialize and validate session on mount
  useEffect(() => {
    const initializeAuth = async () => {
      const savedUser = localStorage.getItem('auth_user');
      if (savedUser) {
        try {
          setUser(JSON.parse(savedUser));
          
          // Verify session is still valid by making a fast API request
          const res = await apiClient.get('/users');
          // Find if demo user details are still returned
          const demoUser = res.data.rows?.find(u => u.username === 'demo');
          if (demoUser) {
            setUser({
              id: demoUser.id,
              name: demoUser.name || 'Demo Admin',
              username: demoUser.username,
              email: demoUser.email,
              role: demoUser.role || 'Administrator',
              avatar: demoUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150',
            });
          }
        } catch (err) {
          console.warn('Session verification failed, logging out locally:', err);
          logoutLocal();
        }
      }
      setLoading(false);
    };

    initializeAuth();
  }, []);

  const login = async (username, password) => {
    setLoading(true);
    try {
      // 1. Fetch login page (GET) to obtain a fresh CSRF token
      console.log('GET /login to fetch CSRF token...');
      const getLoginRes = await fetch('/login');
      const getLoginHtml = await getLoginRes.text();
      
      const tokenMatch = getLoginHtml.match(/name="_token"\s+value="([^"]+)"/) || getLoginHtml.match(/name="csrf-token"\s+content="([^"]+)"/);
      if (!tokenMatch) {
        throw new Error('Failed to retrieve CSRF token from login page.');
      }
      const csrfToken = tokenMatch[1];
      updateCsrfMeta(csrfToken);

      // 2. Perform authentication (POST /login)
      console.log('POST /login to authenticate...');
      const params = new URLSearchParams();
      params.append('_token', csrfToken);
      params.append('username', username);
      params.append('password', password);
      params.append('remember', '1');

      const postLoginRes = await fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString(),
      });

      if (postLoginRes.status === 401 || postLoginRes.url.includes('login?error')) {
        throw new Error('Invalid username or password.');
      }

      // 3. Request /account/api (GET) to ensure geomind_passport_token is set
      console.log('GET /account/api to set passport cookie...');
      const apiPageRes = await fetch('/account/api');
      const apiPageHtml = await apiPageRes.text();
      
      // Update CSRF token from the dashboard
      const nextCsrfMatch = apiPageHtml.match(/name="csrf-token"\s+content="([^"]+)"/);
      if (nextCsrfMatch) {
        updateCsrfMeta(nextCsrfMatch[1]);
      }

      // 4. Fetch user details from /api/v1/users using established session cookies
      console.log('Fetching user details from API...');
      const usersRes = await apiClient.get('/users');
      const apiUser = usersRes.data.rows?.find(u => u.username === username);
      
      if (!apiUser) {
        throw new Error('Authenticated user details not found in API response.');
      }

      const userProfile = {
        id: apiUser.id,
        name: apiUser.name || 'Demo Admin',
        username: apiUser.username,
        email: apiUser.email,
        role: apiUser.role || 'Administrator',
        avatar: apiUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150',
      };

      setUser(userProfile);
      localStorage.setItem('auth_user', JSON.stringify(userProfile));
      
      // Save static bearer token for API CLI compatibility if needed
      const defaultToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiZjQyN2JkYmQ3YThjZWE0YzlhMGFiOGFjZTZmZTQ5ZmZjNmM0NTJjZjBlYTdhOTRmN2QxNGQ3MTdiOGVkMDJiMjUyOTVhOTc2M2E3NjEwNWUiLCJpYXQiOjE3ODEwOTkyNjcuMzg5NDIyLCJuYmYiOjE3ODEwOTkyNjcuMzg5NDIyLCJleHAiOjIyNTQ0ODQ4NjcuMzgwNzgzLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.CpCjk2hoxsxSJYtkceXCbn07zTRHNSAu0vOXrbQsDL0kHX-wHw-x4jEzWlynz9aL-kD2lDB5qzLiOtDSbbtfH8pcGLw7Smp03FRQbBUDcYwj-EEZSZK3H8Qpa54_tpTe8jXLFw78JCBCpNm0yIgK8Ln988VMWkaxTApe0a7S19zRtNWxw6UEToPJyKTvUWBhTFM2iuTjXT18txmmjTa_LYbQrkgvnlQsrFJSbkiy_YCjl5-vWCSPuh5N7PUNm7C4K5WO2WjHyfLIoIZOpETAqfcpp_NrSQC0GT83u5Kg9MbwkahoKh-HtquDRoxguKfgChS42IShbXHp0VQn4vPHgWhkegNhQ1OP5jptogLaCM7eHMH1B9PMPo_DwE7myWk5uiuArri6x8XyvMzgMQ2jdXWBAmIPXB7X5z0LjoXR7C9K1JFeEkpoYdha7ydlg4uO6lc_MRa9mHYvrmW6SzEjeQsC2M-DPXBMCfEjcK16jNkO756-6G8SqJwrQebhyKwzqa9DU9yWqK3OPKYr4KXu6dAV500B2A-fjxOFUaH-hKN5BuHQQQ-i4aP6--WbeHkH243nEB7A2VLDdpbWIHf4o38_QJ6A0LK9d0GHXrmtJ4s_2dl0cXDsvAPewLBMDAWVXU20Ku5-HJcs86QQsK7oqTAaHilUOx6--Jle0r-r42A';
      localStorage.setItem('auth_token', defaultToken);

      return { success: true };
    } catch (error) {
      console.warn('Backend authentication failed, falling back to mock login:', error);
      
      // Allow demo user to login offline
      if (username === 'demo' && password === '87654321') {
        const mockUser = {
          id: 1,
          name: 'Demo Admin',
          username: 'demo',
          email: 'agrwalsshubham@gmail.com',
          role: 'Super Administrator',
          avatar: 'http://3.6.21.202:8000/uploads/default.png',
        };
        setUser(mockUser);
        localStorage.setItem('auth_user', JSON.stringify(mockUser));
        localStorage.setItem('auth_token', 'mock_token_123456');
        return { success: true };
      }
      
      return { success: false, error: error.message || 'Authentication failed' };
    } finally {
      setLoading(false);
    }
  };

  const logoutLocal = () => {
    setUser(null);
    localStorage.removeItem('auth_user');
    localStorage.removeItem('auth_token');
  };

  const logout = async () => {
    setLoading(true);
    try {
      const csrfTokenMeta = document.querySelector('meta[name="csrf-token"]');
      const csrfToken = csrfTokenMeta ? csrfTokenMeta.getAttribute('content') : '';
      
      const params = new URLSearchParams();
      params.append('_token', csrfToken);

      await fetch('/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString(),
      });
    } catch (e) {
      console.warn('Logout request failed on backend, executing local logout:', e);
    } finally {
      logoutLocal();
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
