import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 3000,
    open: true,
    proxy: {
      '/api': {
        target: 'http://3.6.21.202:8000',
        changeOrigin: true,
      },
      '/login': {
        target: 'http://3.6.21.202:8000',
        changeOrigin: true,
      },
      '/logout': {
        target: 'http://3.6.21.202:8000',
        changeOrigin: true,
      },
      '/account': {
        target: 'http://3.6.21.202:8000',
        changeOrigin: true,
      },
    },
  },
});
